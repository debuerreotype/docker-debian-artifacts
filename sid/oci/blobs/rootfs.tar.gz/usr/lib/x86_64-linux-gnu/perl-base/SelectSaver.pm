package SelectSaver 1.03;

use v5.40;

use Symbol 'qualify';

sub new ($class, $filehandle = undef) {
    my $fh = select;
    select qualify $filehandle, caller if defined $filehandle;
    return bless \$fh, $class;
}

sub DESTROY ($self) { select $$self }

__END__

