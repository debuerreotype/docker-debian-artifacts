package attributes 0.37;

use v5.40;

our @EXPORT_OK = qw(get reftype);
our @EXPORT = ();
our %EXPORT_TAGS = (ALL => [@EXPORT, @EXPORT_OK]);

# Older versions of this module provided a `reftype` in attributes.xs, and
# there may exist code out there that relies on being able to find it.
*reftype = \&builtin::reftype;

sub croak {
    require Carp;
    goto &Carp::croak;
}

sub carp {
    require Carp;
    goto &Carp::carp;
}

# Hash of SV type (CODE, SCALAR, etc.) to regex matching deprecated
# attributes for that type.
my %deprecated;

my %msg = (
    lvalue => 'lvalue attribute applied to already-defined subroutine',
   -lvalue => 'lvalue attribute removed from already-defined subroutine',
    const  => 'Useless use of attribute "const"',
);

my sub modify_attrs_and_deprecate ($svtype, @args) {
    # After we've removed a deprecated attribute from the XS code, we need to
    # remove it here, else it ends up in @badattrs. (If we do the deprecation in
    # XS, we can't control the warning based on *our* caller's lexical settings,
    # and the warned line is in this package)
    grep {
	$deprecated{$svtype} && /$deprecated{$svtype}/ ? do {
	    warnings::warnif('deprecated', "Attribute \"$1\" is deprecated, " .
                                           "and will disappear in Perl 5.28");
	    0;
	} : $svtype eq 'CODE' && exists $msg{$_} ? do {
	    warnings::warnif(
		'misc',
		 $msg{$_}
	    );
	    0;
	} : 1
    } _modify_attrs(@args);
}

sub import {
    @_ > 2 && ref $_[2] or do {
	require Exporter;
	goto &Exporter::import;
    };
    my (undef,$home_stash,$svref,@attrs) = @_;

    my $svtype = uc reftype($svref);
    my $pkgmeth;
    $pkgmeth = UNIVERSAL::can($home_stash, "MODIFY_${svtype}_ATTRIBUTES")
	if defined $home_stash && $home_stash ne '';
    my @badattrs;
    if ($pkgmeth) {
	my @pkgattrs = modify_attrs_and_deprecate($svtype, $svref, @attrs);
	@badattrs = $pkgmeth->($home_stash, $svref, @pkgattrs);
	if (!@badattrs && @pkgattrs) {
            require warnings;
	    return unless warnings::enabled('reserved');
	    @pkgattrs = grep { m/\A[[:lower:]]+(?:\z|\()/ } @pkgattrs;
	    if (@pkgattrs) {
		for my $attr (@pkgattrs) {
		    $attr =~ s/\(.+\z//s;
		}
		my $s = ((@pkgattrs == 1) ? '' : 's');
		carp "$svtype package attribute$s " .
		    "may clash with future reserved word$s: " .
		    join(' : ' , @pkgattrs);
	    }
	}
    }
    else {
	@badattrs = modify_attrs_and_deprecate($svtype, $svref, @attrs);
    }
    if (@badattrs) {
	croak "Invalid $svtype attribute" .
	    (( @badattrs == 1 ) ? '' : 's') .
	    ": " .
	    join(' : ', @badattrs);
    }
}

sub get :prototype($) ($svref) {
    ref $svref or
	croak 'Usage: '.__PACKAGE__.'::get $ref';
    my $svtype = uc reftype($svref);
    my $stash = _guess_stash($svref) // scalar caller;
    my $pkgmeth;
    $pkgmeth = UNIVERSAL::can($stash, "FETCH_${svtype}_ATTRIBUTES")
	if defined $stash && $stash ne '';
    return $pkgmeth ?
		(_fetch_attrs($svref), $pkgmeth->($stash, $svref)) :
		(_fetch_attrs($svref))
	;
}

sub require_version { goto &UNIVERSAL::VERSION }

require XSLoader;
XSLoader::load();

__END__
#The POD goes here

